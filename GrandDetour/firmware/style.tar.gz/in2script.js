// Copyright 2005 In2 Networks
var timeout_state = null;
var pressed = 0;
var tick = 0;
var command = 0;

var iconimgs = new Array();
var iconnames = ["Play", "Stop", "Pause", "Forward", "Reverse", "Up", "Down", "Left", "Right", "Record", "Mute", "Off", "On", "Track Forward", "Track Reverse"]; 
var icons = 15;
var img = 0;
var allowPress = true;
var allowHover = true;

var nextpage = null;
var auth = false;
var group = 0;
var node = 0;
var unit = 0;
// var guiid = 0;
var my_timer = 0;
var lastcommand  = null;
var configForm = null;

var buttonupdate = new Array();
var gFeedback_timer = null;		// remove me
var gTarget = 0;
var gAppletId = 0;
var cTick = 0;
var gPassword_timer = null;

function mainPreload()
{
	window.title = "In2 Control";
	thestyle = document.styleSheets[0].href;
	stylepath = thestyle.slice(0,-12);
	if (navigator.platform == "WinCE")
	{
		allowPress = false
	}
	if (stylepath.length == 0)
	{
		// allowPress = false
	}
	for(i = 0; i < icons; i++) 
	{
		var regexp = / /g
		name = iconnames[i].toLowerCase();

		iconimgs[i] = new Image();
		iconimgs[i].src = stylepath + name.replace(regexp, "_") + ".gif";
		seticon(iconnames[i], iconimgs[i].src);
	}

	nodeobj = document.getElementById("node");
	if (nodeobj)
	{
		node = nodeobj.name;
	}
	unitobj = document.getElementById("unit");
	if (unitobj)
	{
		unit = unitobj.name;
	}
	//	getAnchors();
}
function preload_header(grp, app, id)
{
	if (grp)
	{
		group = grp;
	}
	else
	{
		group = 0;
	}

	gUnit = 0;

	if ((app == 0) || (!navigator.javaEnabled()))
	{
		gFeedback_timer = setInterval("getfeedback()", 5000);
	}
	if (id)
	{
 		gAppletId = id;
	}
	else
	{
 		gAppletId = 1;
	}
}
function getfeedback()
{
	tick++;
	if (parent.feedbackframe)
	{
		parent.feedbackframe.location.href = gTarget + "&tick=" + tick; 
	}
}
function seticon(name, icon)
{
	t = document.getElementsByTagName("td");
	for(var i = 0; i < t.length; i ++)
	{
		if(t[i].name == "icon." + name)
		{
			t[i].name = t[i].name.substr(5);
			t[i].innerHTML = "<img class='icon' src='" + icon + "'>";
		}
	}
}
function repeatme() 
{
	if (pressed && lastcommand) 
	{
		parent.hidden.location.href = lastcommand; 
		timeout_state = setTimeout("repeatme()", "200");
	}
}
function baseClass(name)
{	
	var ret;
	if (name.indexOf("_") != -1)
	{
		ret = name.substring(0, name.indexOf("_"));
		return ret;
	}
	return name;
}
function subClass(name)
{
	var ret = ""
	if (name.indexOf("_") != -1)
	{
		ret = name.substring(name.indexOf("_"));
		return ret;
	}
	return ret;
}
function UpdateParagraph(o)
{
	var base = baseClass(o.className);
	if(o.className)
	{
		switch (base)
		{
			case "buttona": 
			case "buttonb": 
			case "buttonc": 
			case "buttond": 
			case "buttonn": 
			case "buttonm":
				if(o.firstChild.nodeName == "P")
				{
				   o.firstChild.className = base.substring(6) + subClass(o.className);
				}
				break;
			default: 
				break;
		}
	}
}


function down(o) 
{ buttonPress(o); }

function over(o) 
{ hover(o); }

function up(o) 
{ button(o); }

function hover(o) 
{
	pressed = 0;
	if (allowHover)
	{
		if (o.id && buttonOn(o.id))
		{
			o.className = baseClass(o.className) + "_hover_on";
		}
		else
		{
			o.className = baseClass(o.className) + "_hover";
		}
	}
	UpdateParagraph(o);
}
function button(o) 
{
	pressed = 0;
	if (allowPress)
	{
		if (o.id)
		{
			if (buttonOn(o.id))
			{
				buttonupdate[o.id] = 1;	
				o.className = baseClass(o.className) + "_hover";
			}
			else
			{
				buttonupdate[o.id] = 2;	
				o.className = baseClass(o.className) + "_hover_on";
			}
		}
		else
		{
			o.className = baseClass(o.className);
		}
		UpdateParagraph(o);
	}
}
function out(o) 
{
	pressed = 0;
	if (allowHover)
	{
		if (o.id && buttonOn(o.id))
		{
			o.className = baseClass(o.className) + "_on";
		}
		else
		{
			o.className = baseClass(o.className);
		}
		UpdateParagraph(o);
	}
}
function toggle(o, cmd) 
{
	var newcmd = cmd;
	if (buttonPress(o) == 1)
	{
		newcmd = cmd + " Off";
	}
	tick++;
	lastcommand = "/cmd?cmd=(0." + node + "." + unit + ")" + newcmd + "&tick=" + tick;
	parent.hidden.location.href = lastcommand; 
}
function press(o, cmd) 
{
	buttonPress(o);
	tick++;
	lastcommand = "/cmd?cmd=(0." + node + "." + unit + ")" + cmd + "&tick=" + tick;
	parent.hidden.location.href = lastcommand; 
}
function repeat(o, cmd) 
{
	buttonPress(o);
	pressed = 1;
	tick++;
	lastcommand = "/cmd?cmd=(0." + node + "." + unit + ")" + cmd + "&tick=" + tick;
	parent.hidden.location.href = lastcommand; 
	timeout_state = setTimeout("repeatme()", "200");
}
function pressgrp(o, cmd) 
{
	buttonPress(o);
	tick++;
	lastcommand = "/cmd?cmd=(" + group + ".0.0)" + cmd + "&tick=" + tick;
	parent.hidden.location.href = lastcommand; 
}
function repeatgrp(o, cmd) 
{
	buttonPress(o);
	pressed = 1;
	tick++;
	lastcommand = "/cmd?cmd=(" + group + ".0.0)" + cmd + "&tick=" + tick;
	parent.hidden.location.href = lastcommand; 
	timeout_state = setTimeout("repeatme()", "200");
}
function loadpage(page) 
{
	parent.controlframe.location.href = page + "&tick=" + tick;
}
function pressgo(o, loc, node, unit) 
{
	buttonPress(o);
	tick++;
	var monitor = "&cmd=(0.0.0)Monitor_" + node + "_" + unit + "_" + parent.headerframe.gAppletId;
	var select = "&cmd1=(" + group + ".0.0)Select_" + node + "_" + unit;
	parent.controlframe.location.href = loc + monitor + select + "&tick=" + tick;
	if (parent.headerframe)
	{
		var vloc = loc.indexOf("control");
		if(vloc != -1)
		{
			parent.headerframe.gTarget = loc.substring(0, vloc) + "vardata?unit=" + unit;
		} 
	}
}
function pressctrl(o, loc) 
{
	buttonPress(o);
	parent.controlframe.location.href = loc; 
}
function pressnav(o, cmd) 
{
	buttonPress(o);
	parent.navframe.location.href = cmd + "&group=" + group;
}
function buttonOn(id)
{
	if ((buttonupdate[id]) && (buttonupdate[id] > 1))
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
function buttonPress(o)
{
	var retval = 0;
	if (allowPress)
	{
		if (o.id && buttonOn(o.id))
		{
			o.className = baseClass(o.className) + "_press_on";
			retval = 1;
		}
		else
		{
			o.className = baseClass(o.className) + "_press";
		}
		UpdateParagraph(o);
		return retval;
	}
}
function breakout()
{
	if (window.top != window.self) 
	{
		window.top.location="/password.htm"
	}
}
function getVar(match)
{
	var i, f, a;
	var myunit = 0;
	var userform = new Array();
	var anchors = new Array();
	var prefix = "";
	userform = document.configform;
	for(i = 0; i < document.anchors.length; i++)
	{
		a = document.anchors[i];
		if(a.id)
		{
			avar = searchVarPrefix(a.id, prefix);
			if (avar == "unit")
			{
				myunit = a.name;
				if (match)
				{
					if (match == "unit")
					{
						prefix = "unit.";
					}
					else
					{
						prefix = "unit." + myunit + "." + match + ".";
					}
				}
				else
				{
					prefix = "unit." + myunit + ".";
				}
			}
			UpdateText(avar, document.anchors[i].name);
			anchors[avar] = a.name;
		}
	}
	for(f = 0; f < userform.length; f ++)
	{
		if (userform[f].name)
		{
			if(userform[f].name == "*Unit")
			{
				userform[f].value = myunit;	 
			}
			var baseUnit = myunit;
			var username;
			if(userform[f].name == "*Unit.info.name")
			{
				username = baseUnit + ".info.name";	
				userform[f].name = username;
			}
			else if(userform[f].name == "*Unit1.info.name")
			{
				baseUnit++;
				username = baseUnit + ".info.name";
				userform[f].name = username;
			}
			else if(userform[f].name == "*Unit2.info.name")
			{
				baseUnit++;
				baseUnit++;
				username = baseUnit + ".info.name";
				userform[f].name = username;
			}
			if(anchors[userform[f].name])
			{
				if (userform[f].type == "radio")
				{
					if(userform[f].value == anchors[userform[f].name])
					{
						userform[f].checked = true;
					}
					else
					{
				   		userform[f].checked = false;
					}
				}          
				else if (userform[f].type == "select-one")
				{					
					for(var idx = 0; idx < userform[f].options.length; idx++)
					{							
						if(userform[f].options[idx].value == anchors[userform[f].name])
						{
							userform[f].selectedIndex = idx;
							break;
						}
					}
				}
				else if (userform[f].type == "checkbox")
				{
					if(anchors[userform[f].name] == "on")
					{
						userform[f].checked = true;
					}
					else
					{
						userform[f].checked = false;
					}
				}
				else if (userform[f].type == "hidden")
				{
					if (userform[f].value == "")
					{
						userform[f].value = anchors[userform[f].name];
					}
				}
				else
      			{
					userform[f].value = anchors[userform[f].name];	 
				}
			}
		}
	}
}
function searchVarPrefix(varstring, prefix)
{
	if(varstring.indexOf(prefix) != -1)
	{
		varname = varstring.substring(varstring.indexOf(prefix) + prefix.length, varstring.length);
	}
	else
	{
		varname = varstring;
	}
	return varname;
}
function getAnchors()
{
	var myunit = 0;
	var prefix = "";
	var a;
	if (document.anchors.length)
	{
		for(i = 0; i < document.anchors.length; i++)	
		{   
			a = document.anchors[i];
			if (a)
			{
				avar = searchVarPrefix(a.id, prefix);
				if (avar == "unit")
				{
					myunit = a.name;
					prefix = "unit." + myunit + ".variable.";
				}
				UpdateText(avar, document.anchors[i].name);
			}
		}
	}
}
function loadVardata()
{
	{
		var a;
		if (document.anchors.length)
		{
			for(i = 0; i < document.anchors.length; i++)	
			{   
				a = document.anchors[i];
				if (a)
				{
					if (parent.nodeframe)
					{
					}
					else
					{
						mc_update(a.id, a.name);
						mc_updateTemp();
					}
				}
			}
		}
	}
}

function UpdateText(name, value)
{
	var tagList = new Array();
	var i = 0;
	var o;
	var key;
	var base;
	var debug = "x";
	var a = 0;
	var action;
	tagList = document.getElementsByTagName("td");
	if (tagList)
	{
		for(a = 0; a < tagList.length; a++)
		{
			o = tagList[a]; 
			tagname = "text." + name;		
			if(o.getAttribute("name") == tagname)
			{
				if (o.className)
				{
					if(value == " ")
					{
						o.style.display = "none";	
					}					
					base = baseClass(o.className);
					switch (base)
					{
						case "buttona": 
						case "buttonb": 
						case "buttonc": 
						case "buttond": 
						case "buttonn": 
						case "buttonm":
						case "buttonh":
						case "buttont":
							if(o.firstChild.nodeName == "P")
							{							
								o.firstChild.className = base.substring(6) + subClass(o.className);

								if(o.firstChild.firstChild)
								{
									o.firstChild.firstChild.nodeValue = value;
								}
							}
							break;
						default: 
							o.innerHTML = "<p class='c'>" + value + "</p>"; 
							break;
					}
				}
			}

			if (o.id)
			{
				action = 0;

				key = o.id.substring(0, o.id.indexOf("!="));

				if (key != -1)
				{
					if (key == name)
					{
						if (o.id == (name + "!=" + value))
						{
							action = -1;
						}
						else
						{
							action = 1;
						}	
					}
				}
					
				if (action == 0)
				{
					key = o.id.substring(0, o.id.indexOf("="));

					if (key != -1)
					{
						if (key == name)
						{
							if (o.id == (name + "=" + value))
							{
								action = 1;
							}
							else
							{
								action = -1;
							}
						}
					}
				}

				if (action == 1)
				{
					if (o.className.indexOf("_hover") != -1)
					{
						o.className = baseClass(o.className) + "_hover_on";
					}
					else
					if (o.className.indexOf("_press") != -1)
					{
						o.className = baseClass(o.className) + "_press_on";
					}
					else
					{
						o.className = baseClass(o.className) + "_on";
					}
					buttonupdate[o.id] = 4;	// really on
				}
				
				if (action == -1)
				{
					if (o.className.indexOf("_hover") != -1)
					{
						o.className = baseClass(o.className) + "_hover";
					}
					else
					if (o.className.indexOf("_press") != -1)
					{
						o.className = baseClass(o.className) + "_press";
					}
					else
					{
						o.className = baseClass(o.className);
					}
					buttonupdate[o.id] = 0;	// really off
				}
			}
		}
	}
}
function setGroup(num)
{
	group = num;
}
function SetNextPage(Unit, NextPage)
{
	var link;
	var page = document.getElementById("page." + Unit);
	var mcpage = document.getElementById("mcpage." + Unit);
	var object = document.getElementById("NextPage");
	if(object)
	{
		if (page)
		{
			if (page.value == "5button.htm")
			{
				object.value = "/config?file=5" + NextPage;
				if (mcpage)
				{
					mcpage.value="mc" + page.value;
				}
			}
			else 
			if (page.value == "10button.htm")
			{
				object.value = "/config?file=10" + NextPage;
				if (mcpage)
				{
					mcpage.value="mc" + page.value;
				}
			}
			else
			if (page.value == "15button.htm")
			{
				object.value = "/config?file=15" + NextPage;
				if (mcpage)
				{
					mcpage.value="mc" + page.value;
				}
			}
		}
		else
		{
			object.value = "/config?file=" + NextPage;
		}
	}
	object = document.getElementById("NextUnit");
	if(object)
	{
		object.value = Unit;
	}
}
function SetMCPage(Unit)
{
	var page = document.getElementById("page." + Unit);
	var mcpage = document.getElementById("mcpage." + Unit);
	if (page)
	{
		if (mcpage)
		{
			mcpage.value="mc" + page.value;
		}
	}
}
function submitform(Unit, NextPage)
{
	SetNextPage(Unit, NextPage);
	document.configform.submit();
}
function loadform(Unit, NextPage)
{
	location.href = "/config?file=" + NextPage + "&unit=" + Unit;
}
function sendcmd(cmd)
{
	tick++;
	parent.vardataframe.location.href = "/cmd?cmd=" + cmd + "&tick=" + tick;
}
function submitformcmd(Unit, NextPage, cmd)
{
	tick++;
	parent.vardataframe.location.href = "/cmd?cmd=" + cmd + "&tick=" + tick;
	SetNextPage(Unit, NextPage);
	document.configform.submit();
}
function showform()
{
	var pageout = "Links: ";
	userform = document.configform;
	for(f = 0; f < userform.length; f ++)
	{
		pageout += userform[f].name + "=" + userform[f].value + "<br>";
		if (userform[f].checked) 
		{
			pageout += "^ Checked <br>" ;
		}
	}
	document.write(pageout);
}
function setPage()
{
	var page = document.getElementById("page");
	var object = document.getElementById("NextPage");
	if(object)
	{
		if (page)
		{
			object.value = page.value;
		}
	}
}
function mc_update(vname, value)
{
	var tagList = new Array();
	tagList = parent.document.getElementsByTagName("td");
	for(a = 0; a < tagList.length; a++)
	{
		o = tagList[a]; 
		var keyname = o.getAttribute("name");
		if(keyname)
		{
			var key = keyname.substring(0, keyname.indexOf("="));
			if (key != -1)
			{
				if (key == vname)
				{
					var curClass = o.className;
					if (keyname == (vname + "=" + value))
					{
						if (curClass.substring((curClass.length -7), curClass.length) == "_hilite")
    					{
        					o.className = "button3on_hilite";
    					}
						else
						{
							o.className = "button3on";
						}
					}
					else
					{
						if (curClass.substring((curClass.length -7), curClass.length) == "_hilite")
    					{
        					o.className = "button3_hilite";
    					}
						else
						{
							o.className = "button3";
						}
					}
				}
			}
		}
	}
}
function mc_updateTemp()
{
	if(document.getElementById("CSP"))
	{
		var csp = document.getElementById("CSP").name;
		var hsp = document.getElementById("HSP").name;
		tempCSP = parent.document.getElementById("text.CSP");
		tempHSP = parent.document.getElementById("text.HSP");
		tempCSP.innerHTML = csp;
		tempHSP.innerHTML = hsp; 
	}	
}

function callfunc()
{
	// alert("callfunc called!");
	for(i = 0; i < icons; i++) 
	{
		seticon(iconnames[i], iconimgs[i].src);
	}
}

function currentNodeUnit(node1, unit1)
{
	//	alert("Node: " + node + "=" + node1 + " Unit: "+ unit + "=" + unit1);
	if ((node == node1) && (unit == unit1))
	{
		// match
		return 1;
	}
	return 0;
}

function preload() 
{

// get node and unit
// compare with main node/unit
try
{
	nodeobj = document.getElementById("node");
	if (nodeobj)
	{
		unitobj = document.getElementById("unit");
		if (unitobj)
		{
			if (parent.currentNodeUnit(nodeobj.name, unitobj.name))
			{
				try
				{	
					srcobj = document.getElementById("control");
					if (srcobj)
					{
						destobj = parent.document.getElementById("frame");
						if (destobj)
						{
							destobj.innerHTML = "";
						}
						destobj = parent.document.getElementById("control");
						if (destobj)
						{
							destobj.innerHTML = srcobj.innerHTML;
						}
					}
					nameobj = document.getElementById("unitname");
					if (nameobj)
					{
						tobj = parent.document.getElementById("title");
						if (tobj)
						{
							tobj.innerHTML = nameobj.innerHTML;
						}
					}
				}
				catch(e)
				{
					// alert("updateControl: " + e);
				}

				var myunit = 0;
				var prefix = "";
				var a;
				var avar;

				if (document.anchors.length)
				{
					for(i = 0; i < document.anchors.length; i++)	
					{   
						a = document.anchors[i];
						if (a)
						{
							avar = searchVarPrefix(a.id, prefix);

							if (avar == "unit")
							{
								myunit = a.name;
								prefix = "unit." + myunit + ".variable.";
							}

							try
							{	
								parent.UpdateText(avar, document.anchors[i].name);
							}
							catch(e)
							{
								// alert("updateControl 1 " + e);
							}
						}
					}
				}
				try
				{	
					parent.callfunc();
				}
				catch(e)
				{
					// alert("updateControl 2 " + e);
				}
			}
		}
	}
	else
	{
		srcobj = document.getElementById("error");
		if (srcobj)
		{
			window.status = srcobj.innerHTML;
		}
	}
}
catch(e)
{
	// ignore errors.
}
}


function preloadFrame(src)
{
	try
	{	
		srcobj = document.getElementById("control");
		if (srcobj)
		{
			destobj = parent.document.getElementById("control");
			if (destobj)
			{
				destobj.innerHTML = "";
			}
			frobj = parent.document.getElementById("nodeframe");
			if (frobj)
			{
				frobj.className = "nodeframe";
			}
		}

		nameobj = document.getElementById("unitname");
		if (nameobj)
		{
			tobj = parent.document.getElementById("title");
			if (tobj)
			{
				tobj.innerHTML = nameobj.innerHTML;
			}
		}
	}
	catch(e)
	{
		// alert("preloadFrame: " + e);
	}
}

function passwordStatus(remote, timeleft)
{
	try
	{	
		// alert("passwordStatus: " + remote + " time: " + timeleft);

		if (remote == "remote")
		{
			// Remote control - can load logout button and enable timeout
			// logout button is hidden by default.

			lobj = parent.document.getElementById("logoutbutton");
			if (lobj)
			{
				lobj.className = "logout";
			}

			// check time remaining
			if (timeleft > 10)
			{
				// set timer for time remaining
				parent.passwordTimer(timeleft);
			}
			else
			{
				// redirect to password CGI
				tick++;
				parent.location.href = "/netpasswd?tout=0&pwmsg=Time expired, Please log in again for more time.&tick=" + tick;
			}
		}
	}
	catch(e)
	{
		// alert("passwordStatus: " + e);
	}
}


function passwordTimer(time)
{
	// set timer for time remaining
	// alert("password timer set to: " + time);
	gPassword_timer = setTimeout("checkPassword()", time*1000);
}


function checkPassword()
{
	nodeobj = document.getElementById("feedbackframe");
	if (nodeobj)
	{
		tick++;
		nodeobj.src = "/netpasswd?time=0&tick=" + tick;
		// nodeobj.src = "/get?file=netpasswd.htm&tick=" + tick;
	}
}
