
function swapMenu(state_a,state_b,state_c)
{
	document.all.box1.style.visibility = state_a;
	document.all.box2.style.visibility = state_b;
	document.all.box3.style.visibility = state_c;
}



function hideMenu()
{
	var cat = new Array();
	var img = new Array();
	var box = new Array();
	var menu = new Array();
	
	cat = ["Security", "Lighting", "Comfort"];
	img = ["box1_img", "box2_img", "box3_img"];
	box = ["box1", "box2", "box3"];
	menu = ["securityMenu", "lightsMenu", "comfortMenu"];
	
	
	for(var i = 0; i < cat.length; i++)
	{
		if(document.getElementById(cat[i]))
		{			 
			//hide them box
			if(document.getElementById(cat[i]))
			{
				a = eval(cat[i]);
				a.style.display = "none";
				
				s = eval(box[i]);
				s.style.display = "none";
				
				d = eval(img[i]);
				d.style.display = "none";
				
				f = eval(menu[i]);
				f.style.display = "none";
				f.MCTempUnFocusable = "true";
			}		
		}
	}
}


