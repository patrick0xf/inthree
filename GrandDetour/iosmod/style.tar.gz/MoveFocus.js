var oCurFocus
var oPrevFocus = null
var sPrevArrowDirection = null
var bFirstMouseover = true

function startFocus()
{
     body.scroll="no"
    window.setTimeout("bFirstMouseover = false", 100)
    try
    {
        if (needViewport() == true)
        {
            window.external.MediaCenter.SharedViewPort.Visible = true
        }
    }
    catch(e)
    {
    }
    if (document.activeElement.MCFocusable == "true")
    {
        body.MCFocusStart = document.activeElement
        body.focus()
    }
    if (oCurFocus == null)
    {
        try
        {
            oCurFocus = eval(body.MCFocusStart)
        }
        catch(e)
        {
        }
    }
    if (oCurFocus == null)
    {
        try
        {
            oCurFocus = aFocusableItemsArray[0]
            if (oCurFocus.id == "SVP")
            {
                oCurFocus = aFocusableItemsArray[1]
            }
        }
        catch(e)
        {
        }
    }

    try
    {
        oCurFocus.focus()
    }
    catch(e)
    {
    }
}
var aFocusableItemsArray = new Array()

function setArray()
{
    var nextElement = 0
    for (i=0; i<body.all.length; i++)
    {
        var obj = body.all(i)
        if (obj.MCFocusable == "true")
        {
            var objPosition = obj.getBoundingClientRect();
            obj.nLeftPos = objPosition.left -2
            obj.nRightPos = objPosition.right -2
            obj.nTopPos = objPosition.top - 2
            obj.nBottomPos = objPosition.bottom -2
            obj.nWidth = (obj.nRightPos - obj.nLeftPos)
            obj.nHeight = (obj.nBottomPos - obj.nTopPos)

            var objCenterTop = (obj.nTopPos+(obj.nHeight/2))
            var objCenterLeft = (obj.nLeftPos+(obj.nWidth/2))
            obj.nCenterYCoord = objCenterTop
            obj.nCenterXCoord = objCenterLeft
            aFocusableItemsArray[nextElement] = obj
            nextElement++
        }
        if (obj.MCSpinnerContainer == "true")
        {
            try
            {
                initializeSpinner(obj)
            }
            catch(e)
            {
             }
        }
    }
}

function checkForOppositeArrow(direction)
{
    if (oPrevFocus == null || sPrevArrowDirection == null) return false
    
    switch(direction)
    {
        case "up":
        {
            if  (sPrevArrowDirection == "down")
            {
                return true;
            }
            break;
        }
        case "down":
        {
            if  (sPrevArrowDirection == "up")
            {
                return true;
            }
            break;
        }
        case "left":
        {
            if  (sPrevArrowDirection == "right")
            {
                return true;
            }
            break;
        }
        case "right":
        {
            if  (sPrevArrowDirection == "left")
            {
                return true;
            }
            break;
        }
    }
    return false
}

function changeFocus(direction)
{
    if (checkForOppositeArrow(direction) == true)
    {
        var oTemp = oCurFocus       
        oCurFocus = oPrevFocus
        oCurFocus.focus()       
        oPrevFocus = oTemp
        sPrevArrowDirection = direction
        return      
    }
    oPrevFocus = oCurFocus
    sPrevArrowDirection = direction
    
    var nearestObj = findClosestItem(direction)
    
    if (nearestObj == null) sPrevArrowDirection = null

    if (oCurFocus.id == "SVP" && nearestObj == null)
    {
        window.external.MediaCenter.SharedViewPort.focus();
        return
    }
    if (oCurFocus.id == "CVP" && nearestObj == null)
    {
        window.external.MediaCenter.CustomViewPort.focus();
        return
    }
    if (nearestObj == null)
    {
        return
    }
    oCurFocus = nearestObj
    oCurFocus.focus()
    if (oCurFocus.id == "SVP")
    {
        window.external.MediaCenter.SharedViewPort.focus();
        return
    }
    if (oCurFocus.id == "CVP")
    {
        window.external.MediaCenter.CustomViewPort.focus();
        return
    }
    try
    {
        if (didScroll())
        {
            updateScrollPositions()
        }
    }
    catch(e)
    {
    }
}


function findClosestItem(direction)
{
    var oOldObj = oCurFocus;
    var nShortestItemDist = 10000
    var oNearestObj = null

    for (i=0; i < aFocusableItemsArray.length; i++)
    {

        oNewObj = aFocusableItemsArray[i]
        if (oNewObj.MCTempUnFocusable == "true") continue
        if (oOldObj == oNewObj)
        {
            continue
        }

        var nTempDist = isInLine(oOldObj, oNewObj, direction)

        if (nTempDist != null && nTempDist < nShortestItemDist)
        {
            nShortestItemDist = nTempDist
            oNearestObj = oNewObj
        }
    }
    if (oNearestObj != null)
    {
        return oNearestObj
    }

    for (i=0; i < aFocusableItemsArray.length; i++)
    {
        oNewObj = aFocusableItemsArray[i]
        if (oNewObj.MCTempUnFocusable == "true") continue
        if (oOldObj == oNewObj) continue

        var nTempDist = isInQuadrant(oOldObj, oNewObj, direction)

        if (nTempDist != null && nTempDist < nShortestItemDist)
        {
            nShortestItemDist = nTempDist
            oNearestObj = oNewObj
        }
    }
    if (oNearestObj != null)
    {
        return oNearestObj
    }

    for (i=0; i < aFocusableItemsArray.length; i++)
    {
        oNewObj= aFocusableItemsArray[i]
        if (oNewObj.MCTempUnFocusable == "true") continue
        if (oOldObj == oNewObj) continue

        var nTempDist = isInHalf(oOldObj, oNewObj, direction)

        if (nTempDist != null && nTempDist < nShortestItemDist)
        {
            nShortestItemDist = nTempDist
            oNearestObj = oNewObj
        }
    }

    if (oNearestObj != null)
    {
        return oNearestObj
    }
    return null
}


function isInLine(oOldObj, oNewObj, direction)
{
    var nStraightDist = null

    if (direction == "down")
    {
        if (oOldObj.nCenterYCoord > oNewObj.nCenterYCoord)
        {
            return null
        }
        if (oOldObj.nLeftPos < oNewObj.nRightPos && oNewObj.nLeftPos < oOldObj.nRightPos)
        {
            nStraightDist = (oNewObj.nTopPos - oOldObj.nBottomPos)
        }
        else
        {
            return null
        }
    }
    if (direction == "up")
    {
        if (oOldObj.nCenterYCoord < oNewObj.nCenterYCoord)
        {
            return null
        }
        if (oOldObj.nLeftPos < oNewObj.nRightPos && oNewObj.nLeftPos < oOldObj.nRightPos)
        {
            nStraightDist = (oOldObj.nTopPos - oNewObj.nBottomPos)
        }
        else
        {
            return null
        }
    }
    if (direction == "left")
    {
        if (oOldObj.nCenterXCoord < oNewObj.nCenterXCoord)
        {
            return null
        }
        if (oOldObj.nTopPos < oNewObj.nBottomPos && oOldObj.nBottomPos > oNewObj.nTopPos)
        {
            nStraightDist = (oOldObj.nLeftPos - oNewObj.nRightPos)
        }
        else
        {
            return null
        }
    }
    if (direction == "right")
    {
        if (oOldObj.nCenterXCoord > oNewObj.nCenterXCoord)
        {
            return null
        }
        if (oOldObj.nTopPos < oNewObj.nBottomPos && oOldObj.nBottomPos > oNewObj.nTopPos)
        {
            nStraightDist = (oNewObj.nLeftPos - oOldObj.nRightPos)
        }
        else
        {
            return null
        }
    }
    return nStraightDist
}

function isInQuadrant(oOldObj, oNewObj, direction)
{
    var xDif = Math.abs(oOldObj.nCenterXCoord - oNewObj.nCenterXCoord);
    var yDif = Math.abs(oOldObj.nCenterYCoord - oNewObj.nCenterYCoord);
    var quadrant
    if(xDif > yDif && oOldObj.nCenterXCoord > oNewObj.nCenterXCoord) quadrant = "left";
    if(xDif > yDif && oOldObj.nCenterXCoord <= oNewObj.nCenterXCoord) quadrant = "right";
    if(xDif <= yDif && oOldObj.nCenterYCoord > oNewObj.nCenterYCoord) quadrant = "up";
    if(xDif <= yDif && oOldObj.nCenterYCoord <= oNewObj.nCenterYCoord) quadrant = "down";

    if (quadrant != direction) return null

    var nQuadDist = Math.sqrt((xDif * xDif) + (yDif * yDif))
    return nQuadDist
}

function isInHalf(oOldObj, oNewObj, direction)
{
    var nHalfDist

        var bIsInCorrectArea = false
        if (direction == "up" && (oOldObj.nCenterYCoord - 40) > oNewObj.nCenterYCoord)
        {
            bIsInCorrectArea = true
        }
        if (direction == "down" && (oOldObj.nCenterYCoord + 40) < oNewObj.nCenterYCoord)
        {
            bIsInCorrectArea = true
        }
        if (direction == "left" && (oOldObj.nCenterXCoord - 40) > oNewObj.nCenterXCoord)
        {
            bIsInCorrectArea = true
        }
        if (direction == "right" && (oOldObj.nCenterXCoord + 40) < oNewObj.nCenterXCoord)
        {
            bIsInCorrectArea = true
        }

        if (bIsInCorrectArea == false) return null

        var xDif = Math.abs(oOldObj.nCenterXCoord - oNewObj.nCenterXCoord);
        var yDif = Math.abs(oOldObj.nCenterYCoord - oNewObj.nCenterYCoord);

        var nHalfDist = Math.sqrt((xDif * xDif) + (yDif * yDif))
    return (nHalfDist)
}


function checkSVP()
{
    try
    {
        if (window.external.MediaCenter.SharedViewPort.Visible == true)
         {
            SVP.MCTempUnFocusable="false"
        }
        else
        {
            SVP.MCTempUnFocusable="true"
        }
    }
    catch(e)
    {
        try
        {
            SVP.MCTempUnFocusable="true"
        }
        catch(e)
        {
        }
    }
}

function checkCVP()
{
    try
    {
        if (window.external.MediaCenter.CustomViewPort.Visible == true)
         {
            CVP.MCTempUnFocusable="false"
        }
        else
        {
            CVP.MCTempUnFocusable="true"
        }
    }
    catch(e)
    {
        try
        {
            CVP.MCTempUnFocusable="true"
        }
        catch(e)
        {
        }
    }
}